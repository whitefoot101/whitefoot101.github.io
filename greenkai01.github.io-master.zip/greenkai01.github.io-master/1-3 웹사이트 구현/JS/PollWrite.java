package kr.koreait.onlinepoll;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class PollWrite {

//	투표 결과를 저장할 텍스트 파일의 경로와 파일명, 텍스트 파일에 저장할 투표 결과가 
//	저장된 ArrayList를 넘겨 받고 텍스트 파일에 저장하는 메서드
	
	public static void pollWrite(String filename, ArrayList<String> poll) {
		
//		ArrayList에 저장된 데이터를 텍스트 파일로 출력할 printWriter 객체를 선언한다.
		PrintWriter printWriter = null;
		
		
		try {
//		ArrayList에 저장된 데이터를 텍스트 파일로 출력할 printWriter 객체를 생성한다
			printWriter = new PrintWriter(filename);
				
//			텍스트 파일로 출력할 객체가 생성되었으므로 ArrayList에 저장된 데이터의 갯수만큼 반복하며 텍스트 파일로 저장한다
			for(String str : poll) {
				printWriter.write(str + "\r\n");
			}
		} catch (FileNotFoundException e) {
			System.out.println("디스크에 파일이 존재하지 않습니다.");
		}finally {
			if(printWriter != null) {printWriter.close();}
		}
		
	}
}