# New-Website-for-Classrooms

학급을 위하여 제도추가제도 투표 기능, 노트필기를 올릴 수 없는 블로그 기능을 구현할 계획이다.

만들 때 참고한 자료들

-투표: https://yoonddo.tistory.com/entry/javaJSP-%ED%88%AC%ED%91%9C%ED%95%98%EA%B8%B0-%EC%B0%BD-%EB%A7%8C%EB%93%A4%EA%B8%B0 https://blog.naver.com/euijun54/221681912413 https://yoonhoou.tistory.com/entry/JSP-DAO-DTO%EB%A5%BC-%ED%86%B5%ED%95%9C-%ED%88%AC%ED%91%9C-%ED%94%84%EB%A1%9C%EA%B7%B8%EB%9E%A8-%EA%B5%AC%ED%98%84

-블로그: https://freehoon.tistory.com/97

-사이트: [https://github.com/greenkai01/greenkai01.github.io.git](https://greenkai01.github.io/)

-git, git 연동, 패이지 기본 설정: https://tired-o.github.io/posts/github-blog-1/ https://velog.io/@pyk0844/%EA%B9%83-%EB%B8%94%EB%A1%9C%EA%B7%B8-%EB%A7%8C%EB%93%A4%EA%B8%B0%EC%89%BD%EA%B2%8C-%EA%B4%80%EB%A6%AC-%ED%95%98%EA%B8%B0 

-git 리포지토리 삭제: https://docs.github.com/ko/repositories/creating-and-managing-repositories/deleting-a-repository

-git 폴더 전체 올리기: https://vanillacreamdonut.tistory.com/193
